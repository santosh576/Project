package com.example.XMLjsonConvertor.Utils;

import java.io.StringReader;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonValue;

public class Utils {
	public static LinkedHashMap<String,JsonValue> getJsonKeyOrNull(JsonObject inputJsonObject)
	{

		LinkedHashMap<String,JsonValue> finalmap=new LinkedHashMap<String,JsonValue>();
		Collection<JsonValue> jsonval=inputJsonObject.values();
		Set<String> set=inputJsonObject.keySet();
		Iterator<String> iteratorkey=set.iterator();
		Iterator<JsonValue> iteratorvalue=jsonval.iterator();
		String key=null;
		JsonValue val=null;
		
		while(iteratorkey.hasNext()&&iteratorvalue.hasNext())
		{
			key=iteratorkey.next();
			 val=iteratorvalue.next();
			 finalmap.put(key,val);
			
		}
	System.out.println(finalmap);
	return finalmap;
	}
	
	
	public static JsonObject getJsonObject(String jsonString) {
		return Json.createReader(new StringReader(jsonString)).readObject();
		
	}
}
