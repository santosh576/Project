package com.example.XMLjsonConvertor.Utils;

import java.util.HashMap;

import javax.json.JsonObject;
import javax.json.JsonValue;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

@Service
public class ConversionImplementation {
	
	@Autowired
	ConverterFactory conversion;
	
	public void convertJSONtoXML(String Payload,String filepath) {
		//Separating each and every line of json
		JsonObject jsonObject=Utils.getJsonObject(Payload);
		//Separating it to  a map
		HashMap<String,JsonValue> mapvalue =Utils.getJsonKeyOrNull(jsonObject);
		
		try {
			//create a new document
			Document doc=conversion.createfileinstance();
			//create a root object in document
			Element root = doc.createElement("object");
			 doc.appendChild(root);
			//appending values to the document by using conversion
			Document document=conversion.createXMLJSONConverter(mapvalue,doc,root);
			
			
			try {
				//writing values to the new created document
				conversion.writefile(document,filepath);
			} catch (TransformerException e) {
				
				e.printStackTrace();
			}
		}
		 catch (ParserConfigurationException e) {
			
			e.printStackTrace();
		}
		


	}
}
