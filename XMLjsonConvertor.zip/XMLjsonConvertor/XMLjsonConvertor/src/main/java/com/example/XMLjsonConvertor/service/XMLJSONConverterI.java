package com.example.XMLjsonConvertor.service;

import java.io.File;
import java.io.IOException;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public interface XMLJSONConverterI {

	public void convertJSONtoXML(MultipartFile json, File xml) throws IOException;
	
}
