package com.example.XMLjsonConvertor.Controller;

import java.io.File;
import java.io.IOException;
import java.util.logging.Logger;


import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.XMLjsonConvertor.Exception.GeneralException;
import com.example.XMLjsonConvertor.service.XMLJSONConverterI;

@RestController
public class ConversionController {
	
	@Autowired
	XMLJSONConverterI xmlconversion;
	
	private static final org.slf4j.Logger logger =  LoggerFactory.getLogger(ConversionController.class);
	
	@PostMapping("/convertxml")
	public void convertfiles(@RequestParam("file") MultipartFile jsonfile)
	{
		//Creating a file
		File xmlfile=new File("C:\\Users\\611594592\\Desktop\\xmlfile.xml");
		try {
			//Calling my service layer from controller
			xmlconversion.convertJSONtoXML(jsonfile, xmlfile);
		} catch (IOException e) {
			logger.error("error while creating file", e.getMessage());
		 e.printStackTrace();
		
		 
		}
	}

}
