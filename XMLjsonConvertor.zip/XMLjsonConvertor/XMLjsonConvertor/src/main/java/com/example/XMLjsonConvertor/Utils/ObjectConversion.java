package com.example.XMLjsonConvertor.Utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import javax.json.JsonValue;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

@Service
public class ObjectConversion {

	boolean isboolean = false;
	boolean isinteger = false;
	boolean isarraylist = false;

	public Document normalconversion(Object payload, Document document) {
		gettype(payload);

		if (payload instanceof Number || isinteger) {

			Element number = document.createElement("number");

			number.appendChild(document.createTextNode(payload.toString()));

			document.appendChild(number);

		} else if (payload instanceof Boolean || isboolean) {
			if (payload.equals("true")) {
				Element trueValue = document.createElement("boolean");

				trueValue.appendChild(document.createTextNode(payload
						.toString()));
				document.appendChild(trueValue);
			} else {
				Element falseValue = document.createElement("boolean");

				falseValue.appendChild(document.createTextNode(payload
						.toString()));
				document.appendChild(falseValue);
			}
		} else if (payload.equals("null")) {
			Element nullValue = document.createElement("null");

			document.appendChild(nullValue);
		}

		else if (payload instanceof String) {

			Element stringValue = document.createElement("string");

			stringValue
					.appendChild(document.createTextNode(payload.toString()));

			document.appendChild(stringValue);
		}

		isboolean = false;
		isinteger = false;
		isarraylist = false;
		return document;
	}

	public void gettype(Object payload) {
		try {
			if ((boolean) payload.toString().contains("[")) {
				isarraylist = true;
			}
			boolean b = Boolean.parseBoolean((String) payload);
			if (b) {
				isboolean = true;
			}
			int i = Integer.parseInt((String) payload);
			{
				isinteger = true;
			}

		} catch (Exception e) {

		}

	}

}
