package com.example.XMLjsonConvertor.Utils;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonValue;
import javax.json.JsonValue.ValueType;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.springframework.stereotype.Service;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;


@Service
public class ConverterFactory {

	public Document createXMLJSONConverter(HashMap<String, JsonValue> valuemap,
			Document document, Element root) {
		String key = null;
		JsonValue value = null;
		for (Map.Entry<String, JsonValue> jsonvalue : valuemap.entrySet()) {
			key = jsonvalue.getKey();
			value = jsonvalue.getValue();
			switch (value.getValueType())

			{
			case NUMBER:

				Element number = document.createElement("number");
				Attr attr = document.createAttribute("name");
				number.setAttributeNode(attr);
				attr.setValue(key);
				number.appendChild(document.createTextNode(value.toString()));
				root.appendChild(number);
				break;

			case STRING:
				Element stringValue = document.createElement("string");
				Attr attribute = document.createAttribute("name");
				stringValue.setAttributeNode(attribute);
				attribute.setValue(key);
				stringValue.appendChild(document.createTextNode(value
						.toString()));
				root.appendChild(stringValue);
				break;

			case ARRAY:
				Element arrayValue = document.createElement("array");
				Attr arrayattribute = document.createAttribute("name");
				arrayValue.setAttributeNode(arrayattribute);
				arrayattribute.setValue(key);
				root.appendChild(arrayValue);
				JsonArray arrayvalue = (JsonArray) value;
				for (JsonValue j : arrayvalue) {
					Enum valuetype = findcase(j);
					if (valuetype == ValueType.OBJECT) {
						Element objectValue = document.createElement("object");

						root.appendChild(objectValue);
						HashMap<String, JsonValue> mapvalues = getmaps(j);
						
						createXMLJSONConverter(mapvalues, document, objectValue);
					}

					else if (valuetype == ValueType.ARRAY) {
						Element objectnewValue = document
								.createElement("array");

						JsonArray arraynewvalue = (JsonArray) j;
						for (JsonValue j1 : arraynewvalue) {
							HashMap<String, JsonValue> mapvalues = getmaps(j1);

							createXMLJSONConverter(mapvalues, document,
									objectnewValue);
							root.appendChild(objectnewValue);
						}
					}

					else {
						Element newarrayvalue = document
								.createElement(valuetype.toString()
										.toLowerCase());
						newarrayvalue.appendChild(document.createTextNode(j
								.toString()));
						arrayValue.appendChild(newarrayvalue);
					}

				}

				break;

			case NULL:
				Element nullValue = document.createElement("null");
				Attr nullattribute = document.createAttribute("name");
				nullValue.setAttributeNode(nullattribute);
				nullattribute.setValue(key);

				root.appendChild(nullValue);
				break;
			case TRUE:
				Element trueValue = document.createElement("boolean");
				Attr trueattribute = document.createAttribute("name");
				trueValue.setAttributeNode(trueattribute);
				trueattribute.setValue(key);
				trueValue
						.appendChild(document.createTextNode(value.toString()));
				root.appendChild(trueValue);
				break;
			case FALSE:
				Element falseValue = document.createElement("boolean");
				Attr falseattribute = document.createAttribute("name");
				falseValue.setAttributeNode(falseattribute);
				falseattribute.setValue(key);
				falseValue
						.appendChild(document.createTextNode(value.toString()));
				root.appendChild(falseValue);
				break;
			case OBJECT:
				Element objectValue = document.createElement("object");
				Attr objectattribute = document.createAttribute("name");
				objectValue.setAttributeNode(objectattribute);
				objectattribute.setValue(key);
				HashMap<String, JsonValue> mapvalue = getmaps(value);
				createXMLJSONConverter(mapvalue, document, objectValue);

				root.appendChild(objectValue);
				break;

			default:
				break;

			}

		}

		return document;

	}

	
	//to get valuetype
	public static Enum findcase(JsonValue value) {

		return value.getValueType();
	}

	public Document createfileinstance() throws ParserConfigurationException {

		DocumentBuilderFactory documentFactory = DocumentBuilderFactory
				.newInstance();

		DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();

		Document document = documentBuilder.newDocument();

		return document;

	}

	public void writefile(Document document, String file)
			throws TransformerException {
		TransformerFactory transformerFactory = TransformerFactory
				.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
		DOMSource domSource = new DOMSource(document);
		StreamResult streamResult = new StreamResult(new File(file));
		transformer.transform(domSource, streamResult);
	}

	public HashMap<String, JsonValue> getmaps(JsonValue value) {
		String s = String.valueOf(value);

		JsonObject jsonObject = Utils.getJsonObject(s);
		HashMap<String, JsonValue> mapvalue = Utils
				.getJsonKeyOrNull(jsonObject);
		return mapvalue;
	}
}
