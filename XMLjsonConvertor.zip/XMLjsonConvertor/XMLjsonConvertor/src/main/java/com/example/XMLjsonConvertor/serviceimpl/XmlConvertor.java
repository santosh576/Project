package com.example.XMLjsonConvertor.serviceimpl;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.example.XMLjsonConvertor.Utils.ConversionImplementation;
import com.example.XMLjsonConvertor.Utils.ConverterFactory;
import com.example.XMLjsonConvertor.Utils.ObjectConversion;
import com.example.XMLjsonConvertor.service.XMLJSONConverterI;

@Service
public class XmlConvertor implements XMLJSONConverterI {

	@Autowired
	ConversionImplementation conversionimplementation;

	@Autowired
	ObjectConversion objectconversion;

	@Override
	public void convertJSONtoXML(MultipartFile json, File xml)
			throws IOException {
		ConverterFactory factory=new ConverterFactory();
		Document documentvalue=null;
		try {
			documentvalue = factory.createfileinstance();
		} catch (ParserConfigurationException e1) {
			
			e1.printStackTrace();
		}
		if (!(json.isEmpty())) {
			// converting bytes of stream data to object
			byte[] bytes = json.getBytes();
			Object Payload = new String(bytes);
			String payloadvalue = String.valueOf(Payload);
			String filepath = xml.toString();
			// check if the inout is json or not
			if (payloadvalue.startsWith("{")) {
				
				conversionimplementation.convertJSONtoXML(payloadvalue,
						filepath);
				
			}
			//COMMENTED OUT AS THERE IS LOGIC ISSUES FOR CONVERTING ARRAY
			/*else if (payloadvalue.startsWith("[")) {
				Element root = documentvalue.createElement("array");
				documentvalue.appendChild(root);
				String StringValue = (String) payloadvalue;
				String[] splittedValues = StringValue.split(",");
				
				try {
					
					for (String value : splittedValues) {
					documentvalue=objectconversion.normalconversion(value,documentvalue);
					}
					root.appendChild(documentvalue);
					factory.writefile(documentvalue, filepath);
				} catch (TransformerException e) {

					e.printStackTrace();
				}
				

			}*/ else {

				documentvalue=objectconversion.normalconversion(Payload,documentvalue);
				try {
					factory.writefile(documentvalue, filepath);
				} catch (TransformerException e) {
					
					e.printStackTrace();
				}

			}
		}

	}
}
