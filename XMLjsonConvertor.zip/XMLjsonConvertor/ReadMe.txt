1.Download the project from the below Git url. 

2. Build the project using maven clean install

3.in conversioncontroller.java change the file path of your choice which will automaticall create a file in particular path

4.Now the service can be started without any issues

5.Input will be in a file and the output will be recieved in a file.